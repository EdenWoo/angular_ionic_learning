angular.module('ionicApp', ['ionic'])

.controller('MyCtrl', function($scope) {
 
  
});